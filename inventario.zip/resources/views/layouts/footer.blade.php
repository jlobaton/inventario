<div class="footer">
	<div class="col-md-12"><p class="text-center">
		Todo los derechos Reservados @ Seguridad y Sistema JM.
	</p>
	</div>
	<div class="col-md-12"><p class="text-center">
		Barquisimeto - Venezuela
	</p>
	</div>
</div>