<hr>
<div class="footer">
Todo los derechos Reservados @ Seguridad y Sistema JM <br>
Barquisimeto - Venezuela
</div>