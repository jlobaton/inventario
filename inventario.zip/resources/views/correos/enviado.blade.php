<table id="Tabla_01" style="width: 630px;" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td><a onmouseover="window.status='Seguridad y Sistema JM';  return true;" onmouseout="window.status='';  return true;" href="http://twitter.com/SyS_JM"> <img src="http://www.seguridadsistema.com.ve/ML/GraciasPorSuCompra/Images/GraciasPorSuCompra_01.png" alt="Seguridad y Sistema JM" width="630" height="102" border="0" /></a></td>
</tr>
<tr>
<td><img src="http://www.seguridadsistema.com.ve/ML/GraciasPorSuCompra/Images/GraciasPorSuCompra_02.png" alt="" width="630" height="48" /></td>
</tr>
<tr>
<td><a onmouseover="window.status='Su Pedido Ha Sido Enviado, Revisar el Archivo Adjunto';  return true;" onmouseout="window.status='';  return true;" href="#"> <img src="http://www.seguridadsistema.com.ve/ML/GraciasPorSuCompra/Images/GraciasPorSuCompra_03.png" alt="Su Pedido Ha Sido Enviado, Revisar el Archivo Adjunto" width="630" height="76" border="0" /></a></td>
</tr>
<tr>
<td>
<ul>
<li><strong>Destinatario:</strong> {{ $nroguia }}</li>
<li><strong>Dirección Destino:</strong> {{ $envdirec }}</li>
<li><strong>Servicio Encomienda:</strong> {{ $encomienda_id }}</li>
<li><strong>Nro de Cupon:</strong> {{ $nroguia }}</li>
<li><strong>Fecha de Envio:</strong> {{ $fecha }}</li>
<li><strong>Total Cajas/Paquetes:</strong> 1</li>
</ul>
<p>&nbsp;</p>
</td>
</tr>
<tr>
	<td>
<h3><strong>IMPORTANTE:</strong></h3>
	</td>
</tr>
<tr>
	<td>
- Puede consultar en todo momento el estatus de su envío visitando la siguiente pagina web <a href="https://www.grupozoom.com/tracking/tracking.php">AQUÍ</a>
<br>
- Todos los productos se envían por solicitud del cliente y viajan por cuenta y riesgo del comprador-cliente
<br>
- No nos hacemos responsable si la mercancía llega en mal estado o por perdida usando cualquier empresa de encomienda o de transporte
<br>
	</td>
</tr>

<tr>
<td><img src="http://www.seguridadsistema.com.ve/ML/GraciasPorSuCompra/Images/GraciasPorSuCompra_04.png" alt="" width="630" height="90" /></td>
</tr>
<tr>
<td><a onmouseover="window.status='Recuerde Calificarnos...';  return true;" onmouseout="window.status='';  return true;" bref="http://www.mercadolibre.com.ve/jm/myML?as_section=MY_PURCH"> <img src="http://www.seguridadsistema.com.ve/ML/GraciasPorSuCompra/Images/GraciasPorSuCompra_05.png" alt="Recuerde Calificarnos..." width="630" height="119" border="0" /></a></td>
</tr>
<tr>
<td><a onmouseover="window.status='Visitenos en Facebook y Twitter';  return true;" onmouseout="window.status='';  return true;" href="#"> <img src="http://www.seguridadsistema.com.ve/ML/GraciasPorSuCompra/Images/GraciasPorSuCompra_06.png" alt="Visitenos en Facebook y Twitter" width="630" height="65" border="0" /></a></td>
</tr>
</tbody>
</table>